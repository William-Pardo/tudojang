
// servicios/api.ts
export * from './usuariosApi';
export * from './estudiantesApi';
export * from './tiendaApi';
export * from './eventosApi';
export * from './configuracionApi';
export * from './notificacionesApi';
export * from './asistenciaApi';
export * from './sedesApi';
export * from './finanzasApi';
export * from './programasApi';
