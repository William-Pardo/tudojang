
  # Mejorar UX

  This is a code bundle for Mejorar UX. The original project is available at https://www.figma.com/design/cY0gh8CrCChkIvUwg5abO1/Mejorar-UX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  