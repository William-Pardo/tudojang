// Este archivo es parte de la funcionalidad de administración de SaaS y no se incluye en la aplicación del cliente.
// La gestión de referidos es una característica de una compilación de solo administrador.
