# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in a `.env` file to your Gemini API key
3. Run the app:
   `npm run dev`

---

## Protocolo de Entrega a Cliente Final

### ⚠️ **Advertencia Importante** ⚠️

**El componente de administración (Dashboard, panel de gestión, componentes admin) nunca debe ser importado ni renderizado en el árbol de componentes del usuario final.**

### Protocolo de Separación de Componentes

1.  **Uso Exclusivo:** Los archivos y componentes de administración (todo lo relacionado con el panel de gestión) solo pueden ser usados o importados durante el desarrollo de dicho panel.

2.  **Exclusión Manual Obligatoria:** Antes de compartir, exportar o publicar la app para un cliente, se debe **eliminar cualquier ruta, import o referencia** a `Dashboard`, `ClientItem`, `ReferralItem`, `Greeting`, `Modal`, `ConfirmationModal` y cualquier otro componente de interfaz de usuario (UI) de administración.

3.  **Código Compartido vs. UI Separada:** El código de lógica y los servicios (ej. `servicios/api.ts`) pueden compartirse entre la vista de administrador y la de cliente. Sin embargo, los **componentes de UI de administración deben ser excluidos manualmente** del bundle antes de entregar la app final al cliente.

### Proceso en la Rama/Producto Final del Cliente

Antes de entregar la aplicación, sigue estos pasos:

1.  **Verificación de Imports:** Verifica manualmente que **NO exista ningún `import` ni ruta** relacionada con los componentes de administración en el código final.

2.  **Eliminación de Rutas:** Si usas un control de rutas (como `react-router-dom`), comenta o elimina cualquier referencia a `/dashboard` u otras rutas administrativas.

3.  **(Opcional) Revisión del Equipo:** Se sugiere encarecidamente que un miembro del equipo revise el árbol de componentes y el código final antes de la entrega para garantizar que no se hayan incluido componentes de administración por error.

### Nota Final sobre el Entorno de Desarrollo

**En Google AI Studio no es posible realizar builds separados ni ocultar componentes mediante variables de entorno.** Por eso, la **eliminación manual** de cualquier componente o ruta de administración en el producto final es **obligatoria y crucial** para la seguridad y la correcta segmentación del producto. No se deben usar scripts de build ni variables de entorno para intentar automatizar esta separación.
